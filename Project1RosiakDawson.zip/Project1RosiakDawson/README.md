## Project 1
# Ryan Rosiak and Grant Dawson

# Datasets
- Grocery Dataset
- San Francisco Crime Dataset
- Wine Quality Dataset